﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculaMediaMakoto
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			double nota1, nota2, media;
			try
			{
				nota1 = double.Parse(textBox1.Text);
				nota2 = double.Parse(textBox2.Text);
				media = Math.Sqrt(nota1  nota2);
				media = Math.Round(media, 2);
				label4.Text = media.ToString();

				if (media >= 5)
				{
					label6.Text = media.ToString("Aprovado");
					label6.ForeColor = System.Drawing.Color.Blue;
				}
				else
				{
					label6.Text = media.ToString("Reprovado");
					label6.ForeColor = System.Drawing.Color.Red;
				}	
	

			}
			catch (Exception erro)
			{
				MessageBox.Show(erro.Message, "***** ERRO ***** ",
					MessageBoxButtons.OK,
					MessageBoxIcon.Error);
				textBox1.Text = " ";
				textBox2.Text = " ";
				label4.Text = " ";
				textBox1.Focus();
			}



		}

		private void button2_Click(object sender, EventArgs e)
		{
			textBox1.Text = " ";
			textBox2.Text = " ";
			label4.Text = " ";
			textBox1.Focus();
		}

		private void button3_Click(object sender, EventArgs e)
		{
			String texto = "Deseja sair do Programa Media do akoto?";
			String titulo = "+++++++ FINALIZANDO +++++++";
			if (MessageBox.Show(texto, titulo, MessageBoxButtons.YesNo,
				MessageBoxIcon.Question,
				MessageBoxDefaultButton.Button1) == DialogResult.Yes)
			{
				Application.Exit();
			}
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void label5_Click(object sender, EventArgs e)
		{

		}

		private void label3_Click(object sender, EventArgs e)
		{

		}
	}
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int numeros[10], i, media;

    for (int i = 0; i <= 9; i++){
        printf("Digite  o n�mero %d: ", i);
        scanf("%d", &numeros[i]);
    }

    printf("escreva um numero");
    scanf("%d",i);

    for (int i = 0; i <= 9; i++)
        media = ((numeros[i]+numeros[9])/2);
        {
        if(numeros[i] % 2 == 0)
        {
            if (numeros > media){
                media = i;
            }

        }
        printf("quantidades de numeros maior que a media eh %d",media);


    }
        return 0 ;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
     double quantidade, total;
     int tipo;

    printf ("Informe a quantidade de kWh consumido: ");
    scanf("%f", &quantidade);

    printf("escreva qual � local, 1 para residencial, 2 para comercial ou 3 para industrial\n");
    scanf("%d", &tipo);

    if(tipo == 1){
        total = 15 + (0.15 * quantidade);
    }
    else if(tipo == 2){
        total = 150;

        if(quantidade > 100){

            total = total + ((quantidade - 100) * 0.55);
        }
    }
    else if (tipo == 3){
        total = 500;

        if(quantidade > 500){

            total = total + ((quantidade - 500) * 0.95);
        }
    }

    printf (" O custo da conta � %.2f",total);

    return 0;
}

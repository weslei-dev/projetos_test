#include <stdio.h>
#include <stdlib.h>


int main()
{

    int numero,soma;

    do{

    printf("digite um numero possitivo!\n");
    scanf("%d",&numero);

      if(numero%2 == 0)
        {
       soma = soma + numero;
    }
    else numero = numero +1;
     }
     while(numero != 1000);


        printf("a soma dos n�mero pares � %d\n",&soma);
        printf("a quantidade de numeros impares � %d",&numero);


    return 0;
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float numero;
    struct numeros
    {

    };


    *ponteiro = &numero;

    scanf("%f", )


    return 0;
}


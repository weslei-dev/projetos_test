#include <stdio.h>
#include <stdlib.h>

int main()
{
    int base_maior,base_menor,altura,area;

            printf("ola, faremos nesse programa a area de um trapezio!\n");
            printf("digite o valor da base maior:\n");
                       scanf ("%d",&base_maior);
            printf("digite o valor da base menor:\n");
            scanf("%d",&base_menor);
            printf("digite o valor da altura:\n");
            scanf("%d",&altura);

            area = (base_maior+base_menor)/2*altura;


            printf("a area do trapezio e %d:\n\n",area);


        return 0;
}

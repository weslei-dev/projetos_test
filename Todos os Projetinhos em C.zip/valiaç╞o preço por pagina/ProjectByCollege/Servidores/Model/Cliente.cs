﻿namespace Servidores.Model
{
    public class Cliente
    {
        public string Id { get; set; }
        public string Nome { get; set; }
        public int Index { get; set; }
    }
}

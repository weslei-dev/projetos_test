﻿namespace Servidores
{
    public enum ETipoServidor
    {
        Unico = 1,
        Multiplo = 2
    }
}

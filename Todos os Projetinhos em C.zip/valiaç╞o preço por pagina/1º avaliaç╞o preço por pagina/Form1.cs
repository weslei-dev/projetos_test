﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1º_avaliação_preço_por_pagina
{
    public partial class Form1 : Form
    {
        double custoMedio;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {

            

            double quantidadeColorida = double.Parse(txtQuantidadeColorido.Text);
            double quantidadePB = double.Parse(txtQuatidadePB.Text);
            

            double custofinal = (quantidadeColorida * 0.25 + quantidadePB * 0.10) / (quantidadeColorida + quantidadePB);
            double custoTotal = (quantidadeColorida * 0.25 + quantidadePB * 0.10);
            if(quantidadeColorida <= 0) 
            { MessageBox.Show("operação é invalida");
                
            }
            if (custoTotal <= 2) 
            {
                txtCustoFinal.BackColor = Color.Green;
            }
            if ( custoTotal >= 2 || custofinal < 6)
            {
                txtCustoFinal.BackColor = Color.Yellow;
            }
            if (custoTotal > 6)
            {
                txtCustoFinal.BackColor = Color.Red;
            }


            string custo = "Custo do livro" + Environment.NewLine
                         + "Quantidade de folhas coloridas:" + quantidadeColorida+ Environment.NewLine
                         + "Quantidade de folhas preto e branco:" + quantidadePB + Environment.NewLine
                         + "Custo total do livro:" + custoTotal+ Environment.NewLine
                         + "---------------------------------------------";

            txtCustoFinal.Text += custo;
            txtCustoMedio.Text += custofinal;
            custoMedio = 0;
                }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtQuantidadeColorido.Text = "";
            txtQuatidadePB.Text = "";
            txtCustoMedio.Text = "";
            txtCustoFinal.Text = "";
            txtCustoFinal.BackColor = Color.White;
            custoMedio = 0;
            
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float variavel;
    int  vetor[4];
    struct informacoes_cadastrais
   {
        int posicao;
   };

   struct informacoes_cadastrais individuo;

   float *ptr = &variavel;
   int *ptrPosicao = &individuo.posicao;

    ptr = 21;
    ptrPosicao = 23;
    for (int i = 0; i <= 3; i++)
    {
        vetor[i] = i;
    }

    alterar(ptr, ptrPosicao, vetor);

    printf("Valor: %f\n", ptr);
    printf("Valor: %d\n", ptrPosicao);
    for (int i = 0; i <= 3; i++)
    {
        printf("Vetor posicao %d: �%d\n", i, vetor[i]);
    }

    return 0;
}

void alterar(float valor, int *ptrPosicao, int vetor[4])
{
    valor = valor + 3;
    ptrPosicao = ptrPosicao + 3;

    for (int i = 0; i <= 3; i++)
    {
        vetor[i] = i + 3;
    }

    printf("Valor: %f\n", valor);
    printf("Valor: %d\n", ptrPosicao);
    for (int i = 0; i <= 3; i++)
    {
        printf("Vetor posicao %d: �%d\n", i, vetor[i]);
    }
}
